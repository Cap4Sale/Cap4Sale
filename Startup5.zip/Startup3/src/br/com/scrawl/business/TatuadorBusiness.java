
package br.com.scrawl.business;

import br.com.scrawl.business.interfaces.TatuadorInterface;
import br.com.scrawl.dominio.Tatuador;
import java.util.List;


        
public class TatuadorBusiness implements TatuadorInterface {

    @Override
    public Tatuador salvarTatuador(Tatuador tatuadorr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Tatuador> buscarTatuadorPorNome(String nome) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Tatuador> buscarTodosTatuadores() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
