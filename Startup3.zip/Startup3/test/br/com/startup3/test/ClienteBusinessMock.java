/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.startup3.test;

import br.com.scrawl.dominio.Cliente;

/**
 *
 * @author internet
 */
public class ClienteBusinessMock {
    
    public static void main (String [] args){
         Cliente novoCliente = new Cliente();
        novoCliente.setNome ("Thiago");
        novoCliente.setEmail ("  ");
        novoCliente.setNomedeusuario("taraujo");
        novoCliente.setTelefone(9879876);
        
        System.err.println("CLIENTE VALIDADO COM SUCESSO");
        
        
        
        
    }
    
    
}
