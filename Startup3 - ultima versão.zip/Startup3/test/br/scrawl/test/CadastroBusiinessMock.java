/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.scrawl.test;

import br.com.scrawl.dominio.Login;
import static br.com.scrawl.repositorio.Repositorio.loginDBFake;
import static sun.security.jgss.GSSUtil.login;

/**
 *
 * @author Thiago Vinicius
 */
public class CadastroBusiinessMock {
    
     
    
}
