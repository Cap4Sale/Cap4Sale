/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.scrawl.business;

import br.com.scrawl.business.interfaces.ArteInterface;
import br.com.scrawl.dominio.Tatuador;
import java.util.List;

public class ArteBusiness implements ArteInterface{

    @Override
    public Tatuador salvarTatuador(Tatuador tatuadorr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Tatuador> buscarTatuadorPorNome(String nome) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Tatuador> buscarTodosTatuadores() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   

    

    
   
    
    
}
