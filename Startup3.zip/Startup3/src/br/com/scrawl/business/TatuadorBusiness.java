
package br.com.scrawl.business;


        
public class TatuadorBusiness {
    
    
}
